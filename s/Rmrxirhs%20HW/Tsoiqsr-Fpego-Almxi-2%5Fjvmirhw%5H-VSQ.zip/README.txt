Pokemon Black 2 & White 2 has been removed due to legal issues.

For Black 2 go to:
http://www.emuparadise.me/Nintendo_DS_ROMs/Pokemon_Black_Version_2_%28DSi_Enhanced%29%28U%29%28frieNDS%29/164832

For White 2 go to:
http://www.emuparadise.me/Nintendo_DS_ROMs/Pokemon_White_Version_2_%28DSi_Enhanced%29%28U%29%28frieNDS%29/164833

Thanks
ROMS4DROID.com